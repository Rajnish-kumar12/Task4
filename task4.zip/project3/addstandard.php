<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="chapter.css"> -->
    <style>
        body {
            background-color: rgb(70, 171, 192);
            padding-top: 100px;
            margin: 30px;
        }

        .sub {
            background-color: rgb(28, 219, 215);
            padding: 10px;
            margin: 5px;
            border-radius: 15px;
            border-color: rgb(35, 226, 255);
            border-style: outset;
            width: 350px;
        }

        .submit {
            background-color: rgb(12, 188, 223);
            padding: 5px;
            margin: 5px;
            border-radius: 5px;
        }

        .field {
            background-color: rgb(110, 165, 205);
            padding: 10px;
            margin: 10px;
            border-radius: 3px;
        }
    </style>
</head>

<body>
    <center>
        <form action="addstandard.php" method="post">
            <div class="sub">
                <input type="text" name="standardname" placeholder="standard name" class="field">
            </div>
            <div>
                <input type="submit" name="submit" class="submit">
            </div>
        </form>
        <div>
            <a href="standard.php"><button class="submit">Back</button></a>
        </div>
    </center>

</body>

</html>
<?php
error_reporting(0);
require_once "conn.php";
if (isset($_POST['submit'])) {
    $standard_name = $_POST['standardname'];
    $sql = "INSERT INTO standard(standard_name) VALUES('$standard_name')";
    $query = mysqli_query($conn, $sql);
    if ($query) {
        echo "standard added";
    } else {
        echo "not added something error";
    }
}
?>