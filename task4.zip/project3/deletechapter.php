<?php
    error_reporting(0);
    require_once "conn.php";
    if($conn)
    {
        echo "database connected";
    }
    else
    {
        echo "database not connected";
    }
    $chapter_no=$_GET['cn'];
    $query="DELETE FROM chapter WHERE chapter_no='$chapter_no'";
    $result=mysqli_query($conn,$query);
    if($result)
    {
        echo "record deleted successfully";
    }
    else
    {
        echo "record not deleted successfully";
    }
?>  