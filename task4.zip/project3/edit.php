<?php
//start the session which are alredy started into the login page
session_start();
//check the session that is started or not
if (!isset($_SESSION['user'])) {
    //if session value are not set then don't open the dashboard page send user to the login page to first login into the website
    header("Location: login.php");
}
?>
<?php
include "conn.php";
$Id = $_GET['id'];
$fullname = $_GET['fullname'];
$email = $_GET['email'];
$country = $_GET['country'];
$state = $_GET['state'];
$address = $_GET['address'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="edit.css">
    <style>
        body {
            background-color: rgb(89, 122, 172);
            padding: 50px;
        }

        .btnssss {
            background-color: rgb(54, 124, 204);
            margin: 10px;
            padding: 5px;
        }

        .input {
            background-color: blanchedalmond;
            padding: 5px;
            margin: 5px;
            width: 250px;
            border: 3px;
            border-radius: 5px;
        }

        .table {
            border-color: rgb(9, 112, 160);
            border-radius: 5px;
        }

        .row {
            border-color: rgb(31, 121, 91);
            /* border-radius: 10px; */
        }
    </style>
</head>

<body>
    <table border="2px" class="table">
        <form action="" method="get" enctype="multipart/form-data">
            <tr class="row">
                <td>Id</td>
                <td><input type="text" value="<?php echo $Id ?>" name="id" readonly class="input"> </td>
            </tr>
            <tr class="row">
                <td>fullname</td>
                <td><input type="text" value="<?php echo $fullname ?>" name="fullname" class="input"></td>
            </tr>
            <tr class="row">
                <td>email</td>
                <td><input type="text" value="<?php echo $email ?>" name="email" class="input"></td>
            </tr>
            <tr class="row">
                <td>countrty</td>
                <td><input type="text" value="<?php echo $country ?>" name="country" class="input"></td>
            </tr>
            <tr class="row">
                <td>state</td>
                <td><input type="text" value="<?php echo $state ?>" name="state" class="input"></td>
            </tr>
            <tr class="row">
                <td>address</td>
                <td><input type="text" value="<?php echo $address ?>" name="address" class="input"></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <input type="submit" name="submit" class="btnssss">
                </td>
            </tr>
        </form>
        <a href="view.php"><button class="btnssss">BACK</button></a>
    </table>
</body>

</html>
<?php
if ($_GET['submit']) {
    include "conn.php";
    $Id = $_GET['id'];
    $fullname = $_GET['fullname'];
    $email = $_GET['email'];
    $country = $_GET['country'];
    $state = $_GET['state'];
    $address = $_GET['address'];
    $query = "UPDATE login SET id='$Id', fullname='$fullname',email='$email',country='$country',state='$state',address='$address' WHERE id='$Id'";
    // print_r($query);
    $result9 = mysqli_query($conn, $query) . mysqli_error($conn);
    // print_r($result9);
    if ($result9) {
        echo "record updated";
    } else {
        echo "record not updated";
    }
}
?>