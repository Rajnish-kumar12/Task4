<?php
//start the session which are alredy started into the login page
    session_start();
    //check the session that is started or not
    if(!isset($_SESSION['user']))
    {
        //if session value are not set then don't open the dashboard page send user to the login page to first login into the website
        header("Location: login.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="stylev.css">
    <a href="home.php"><button class="btnv">Homepage</button>
    <h1>The registered data are:</h1>
    <!-- <a href="home.php"><button class="btnv">Homepage</button> -->
</head>
<body>
    </a>
<table border="5px" style="color: black;">
            <thead>
                <tr>
                    <th>id</th>
                    <th>fullname</th>   
                    <th>email</th>
                    <th>country</th>
                    <th>state</th>
                    <th>address</th>
                    <!-- <th>password</th> -->
                    <th>edit</th>
                    <th>delete</th>
                    <th>view</th>
                </tr>
            </thead>
<tbody>
<?php
    require_once "conn.php";
    $sql="SELECT * FROM login";
    $query=mysqli_query($conn,$sql);
    $n=mysqli_num_rows($query);
    if($query)
    {
        if($n>0)
        {
            // $iCount = 1;
                while($data=mysqli_fetch_assoc($query))
                {
                        $id = $data['id'];
                        $fullname= $data['fullname'];
                        $email = $data['email'];
                        $country = $data['country'];
                        $state=$data['state'];
                        $address = $data['address'];
                        echo "<tr>
                        <th >$id</th>
                        <td>$fullname</td>
                        <td>$email</td>
                        <td>$country</td>
                        <td>$state</td>
                        <td>$address</td>
                        <td><a href='edit.php?id=$data[id]&fullname=$data[fullname]&email=$data[email]&country=$data[country]&state=$data[state]&address=$data[address]'><button class='btnv'>Edit</button></td>
                        <td><a href='delete.php?id=$id'><button class='btnv'>Delete</button></td>
                        <td><a href='viewp.php?id=$id'><button class='btnv'>View</button></td>
                        ";
                        // $iCount++;
                }
        }
       else
       {
        echo "no record found";
       }
    }
?>