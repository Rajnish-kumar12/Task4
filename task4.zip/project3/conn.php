<?php
    $conn=mysqli_connect("localhost","root","root","project3");
    if(!$conn)
    {
        die("something went wrong");
    }
?>