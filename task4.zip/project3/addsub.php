<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet"  href="addsub.css"> -->
    <style>
        body {
            background-color: rgb(13, 124, 175);
            padding: 200px;
            /* margin: 100px; */
        }

        .btn {
            width: 300px;
            background-color: antiquewhite;
            padding: 20px;
            border-radius: 5px;
            border-color: rgb(3, 150, 101);
            /* border: 6px; */
        }

        .btns {
            background-color: aqua;
            padding: 5px;
            border-radius: 5px;
            border-color: rgb(3, 150, 101);
        }

        .control {
            padding: 20px;
        }

        .addsub {
            background-color: rgb(79, 193, 235);
            width: 600px;
            border: 3px solid rgb(0, 255, 255);
            padding: 5px;
            border-radius: 10px;
        }

        .h1 {
            color: aquamarine;
        }
    </style>
</head>

<body>
    <center>
        <form action="addsub.php" method="post">
            <marquee>
                <h1 class="h1">ADD SUBJECT</h1>
            </marquee>
            <div class="addsub">
                <div class="control">
                    <!-- <label for="">Subject name:</label> -->
                    <input type="text" name="subname" class="btn" placeholder="subject name">
                </div>
                <input type="submit" name="submit" class="btns">
            </div>
            </div>
        </form>
        <a href="subject.php"><button class="btns">BACK</button></a>
    </center>
</body>

</html>
<?php
error_reporting(0);
require_once "conn.php";
if (isset($_POST['submit'])) {
    $subject_name = $_POST['subname'];
    $sql = "INSERT INTO subject(subject_name) VALUES('$subject_name')";
    $query = mysqli_query($conn, $sql);
    if ($query) {
        echo "subject added";
    } else {
        echo "not added something error";
    }
}
?>