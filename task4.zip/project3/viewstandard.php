<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet"  href="viewchapter.css"> -->
    <style>
        body {
            background-color: rgb(70, 171, 192);
            padding-top: 100px;
            margin: 30px;
        }
        .btn {
            background-color: aqua;
            padding: 3px;
            margin: 6px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <center>
        <table border="2px">
            <h1>VIEW STANDARD</h1>
            <thead>
                <tr style="text-align: center;">
                    <td>standard_name</td>
                    <td>Edit</td>
                    <td>Delete</td>
                </tr>
                <tr>
                    <?php
                    require_once "conn.php";
                    $sql = "SELECT * FROM standard";
                    $result = mysqli_query($conn, $sql);
                    while ($data = mysqli_fetch_assoc($result)) {
                    ?>
                        <td><?php echo $data['standard_name'] ?></td>
                        <td><a href="editstandard.php"><button class="btn">Edit standard</button></a></td>
                        <td><a href="deletestandard.php"><button class="btn">Delete standard</button></a></td>
                </tr>
            <?php
                    }
            ?>
            </thead>
        </table>
        <a href="standard.php"><button class="btn">Back</button></a>
    </center>
</body>

</html>