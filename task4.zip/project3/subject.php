<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="subject.css"> -->
    <style>
        body {
            background-color: rgb(13, 124, 175);
            padding: 50px;
            margin: 50px;
        }

        .btn {
            background-color: rgb(11, 204, 204);
            padding: 25px;
            margin: 15px;
            border-radius: 12px;
            border-color: rgb(6, 233, 157);
        }
    </style>
</head>

<body>
    <center>
        <marquee behavior="" direction="">
            <h1 style="color: lightblue;">SUBJECT SECTION</h1>
        </marquee>
        <div class="control">
            <div class="sub">
                <a href="addsub.php"><button class="btn">ADD SUBJECT</button></a>
            </div>
            <div class="sub">
                <a href="viewsub.php"><button class="btn">VIEW SUBJECT</button></a>
            </div>
            <!-- <div class="sub">
            <a href="delsub.php"><button class="btn">DELETE SUBJECT</button></a>
            </div> -->
        </div>
    </center>
</body>

</html>