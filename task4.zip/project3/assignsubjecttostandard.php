<!DOCTYPE html>
<html>
<head>
<title>Assign Subjects to standards</title>
</head>
<body>
<h1>Assign Subjects to standard</h1>
<form action="assignsubjecttostandard.php" method="post">
<select name="standard">
<option value="">Select a standard</option>
<?php 
// $connection = mysqli_connect('localhost', 'root', 'root', 'userdata');
require_once "conn.php";
$sql = "SELECT * FROM standard";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $standard_id= $row['standard_name'];
echo "<option value='$standard_id'>$standard_id</option>";
}
// die();
?>
</select>
<br>
<br>
<select name="subject">
<option value="">Select a subject</option>
<?php
$sql = "SELECT * FROM subject";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $subject_id = $row['subject_name'];
echo "<option value='$subject_id'>$subject_id</option>";
}
?>
</select>
<br>
<br>
<input type="submit" name="assign_chapter"value="Assign Chapter">
</form>
</body>
</html>
<?php
if (isset($_POST['assign_chapter'])) {
    $standard_name = $_POST['standard'];
    $subject_name = $_POST['subject'];
    $assign_chap_query = "insert into assign_1 (standard_name, subject_name) values ('$standard_name', '$subject_name')";
    $result = mysqli_query($conn, $assign_chap_query);
    // print_r($assign_chap_query);
    // die();
    if ($result) {
       echo "assign subject";
    } else {
    }
}
?>