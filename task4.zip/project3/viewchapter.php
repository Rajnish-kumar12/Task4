</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>chapter</title>
    <link rel="stylesheet" href="stylev.css">
        <h1>The chapters are:</h1></a>
</head>

<body>
    <table border="3px" style="color: black;">
        <tr>
            <td>chapter_no</td>
            <td>chapter_nanme</td>
            <td>Edit</td>
            <td>Delete</td>
        </tr>
        <tbody>
            <?php
            require_once "conn.php";
            $sql = "SELECT * FROM chapter";
            $query = mysqli_query($conn, $sql);
            $n = mysqli_num_rows($query);
            if ($query) {
                if ($n > 0) {
                    while ($data = mysqli_fetch_assoc($query)) {
                        $chapter_no = $data['chapter_no'];
                        $chapter_name = $data['chapter_name'];
                        echo "<tr>
                        <th >$chapter_no</th>
                        <td>$chapter_name</td>
                        <td><a href='editchapter.php?cn=$data[chapter_no]&cnm=$data[chapter_name]'><button class='btnv'>Edit</button></td>
                        <td><a href='deletechapter.php?cn=$chapter_no'><button class='btnv'>Delete</button></td>
                        ";
                    }
                } else {
                    echo "no record found";
                }
            }
            ?>
        </tbody>
    </table>
    <a href="chapter.php"><button>BACK</button></a>
</body>
</html>