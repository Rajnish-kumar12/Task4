<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="admin.css"> -->
    <style>
        body {
            background-color: aquamarine;
            padding: 50px;
            /* margin: 50px; */
        }

        .admins {
            background-color: rgb(226, 178, 178);
            border-radius: 4px;
            padding: 5px;
            margin: 5px;
        }
    </style>
</head>

<body>
    <center>
        <div>
            <a href="subject.php"><button class="admins">subject section</button></a>
        </div>
        <div>
            <a href="chapter.php"><button class="admins">chapter section</button></a>
        </div>
        <div>
            <a href=""><button class="admins">assign chapter</button></a>
        </div>
        <div>
            <a href=""><button class="admins">assign subject</button></a>
        </div>
        <div>
            <a href=""><button class="admins">assign student</button></a>
        </div>
    </center>
</body>

</html>