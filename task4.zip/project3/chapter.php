<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="chapter.css">   -->
    <style>
        body {
        background-color: rgb(70, 171, 192);
        padding-top: 100px;
        margin: 30px;
            }
        .btn {
        background-color: rgb(28, 219, 215);
        padding: 10px;
        margin: 15px;
        border-radius: 20px;
        border-color: aquamarine;
        border-style: outset;
        }
        .control {
        border: 2px solid rgb(46, 137, 255);
        width: 400px;
        height: 300px;
        border-radius: 20px;
        border-style: inset;
        background-color: rgb(144, 226, 251);
        }

    </style>
</head>
<body>
    <center>
    <div class="control">
        <div class="chapter">
        <h1>CHAPTER SECTION</h1>
        </div>
        <div class="chapter">
            <a href="addchapter.php"><button class="btn">ADD CHAPTER</button></a>
        </div>
        <div class="chapter">
            <a href="viewchapter.php"><button class="btn">VIEW CHAPTER</button></a>
        </div>
    </center>
    </div>
</body>
</html>