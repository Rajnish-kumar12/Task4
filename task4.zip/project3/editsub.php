<?php
error_reporting(0);
include "conn.php";
$subject_id = $_GET['si'];
$subject_name = $_GET['snm'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit chapter</title>
    <!-- <link rel="stylesheet" href="editsub.css"> -->
    <style>
        body {
            padding: 100px;
            background-color: rgb(13, 124, 175);
            /* width: 200px; */
        }

        .input {
            background-color: rgb(128, 176, 218);
            padding: 20px;
            width: 220px;
            border-radius: 10px;
        }

        .btnssss {
            background-color: rgb(94, 250, 86);
            padding: 10px;
            border-color: green;
            margin: 5px;
            border-radius: 5px;
        }

        .edit-control {
            border-color: aquamarine;
        }

        .extra {
            padding: 10px;
        }
    </style>
</head>

<body>
    <div class="edit-control">
        <center>
            <marquee behavior="" direction="">
                <h1>EDIT SUBJECT</h1>
            </marquee>
            <table border="2px" class="table" style="border-radius: 5px;">
                <form action="" method="get">
                    <tr class="row">
                        <td class="extra">subject_id</td>
                        <td><input type="text" value="<?php echo $subject_id ?>" name="subject_id" class="input"> </td>
                    </tr>
                    <tr class="row">
                        <td class="extra">subject_name</td>
                        <td><input type="text" value="<?php echo $subject_name ?>" name="subject_name" class="input"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" name="submit" class="btnssss">
                        </td>
                    </tr>
                </form>
            </table>
            <a href="viewsub.php"><button class="btnssss">BACK</button></a>
        </center>
    </div>
</body>

</html>
<?php
error_reporting(0);
if ($_GET['submit']) {
    include "conn.php";
    $subject_id = $_GET['subject_id'];
    $subject_name = $_GET['subject_name'];
    $query = "UPDATE subject SET subject_id='$subject_id', subject_name='$subject_name' WHERE subject_id='$subject_id'";
    $result9 = mysqli_query($conn, $query) . mysqli_error($conn);
    if ($result9) {
        echo "updated";
    } else {
        echo "not updated, error";
    }
}
?>