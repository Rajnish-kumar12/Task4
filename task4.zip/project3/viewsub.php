</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>chapter</title>
    <!-- <link rel="stylesheet" href="viewsub.css"> -->
    <marquee behavior="" direction="">
        <h1 style="color:blue">The subjects are:</h1></a>
    </marquee>
    <style>
        body {
            background-color: rgb(13, 124, 175);
            padding: 200px;
            /* width: 600px; */
            /* margin-right: ; */
            /* padding-right: 200px; */
            align-items: center;
        }

        .btnv {
            background-color: rgb(164, 208, 87);
            border-color: rgb(18, 175, 253);
            padding: 15px;
            margin: 5px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <table border="3px" style="color: black;">
        <center>
            <tr>
                <td>subject_id</td>
                <td>subject_name</td>
                <td>Edit</td>
                <td>Delete</td>
            </tr>
            <tbody align="center">

                <?php
                require_once "conn.php";
                $sql = "SELECT * FROM subject";
                $query = mysqli_query($conn, $sql);
                $n = mysqli_num_rows($query);
                if ($query) {
                    if ($n > 0) {
                        while ($data = mysqli_fetch_assoc($query)) {
                            $subject_id = $data['subject_id'];
                            $subject_name = $data['subject_name'];
                            echo "<tr>
                        <th >$subject_id</th>
                        <td>$subject_name</td>
                        <td><a href='editsub.php?si=$data[subject_id]&snm=$data[subject_name]'><button class='btnv'>Edit</button></td>
                        <td><a href='delsub.php?si=$subject_id'><button class='btnv'>Delete</button></td>
                        ";
                        }
                    } else {
                        echo "no record found";
                    }
                }
                ?>

            </tbody>
        </center>
    </table>
    <a href="subject.php"><button class="btnv">BACK</button></a>
</body>

</html>