<?php
session_start();
    //check the session that is started or not
    if(isset($_SESSION['user']))
    {
        //if user are already login redirect to the home page
        header("Location: home.php");
    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <center></center>
    <div class="container">
        <form action="login.php" method="post">
        <div class="tag">
            <h1>PLEASE LOGIN HERE :</h1>
        </div>
        <div class="form_group">
            <input type="email" name="email" class=form-control placeholder="enter your registered email">
        </div>
        <div class="form_group">
            <input type="password" name="password" class="form-control" placeholder="enter your password">
        </div>
        <div class="form_group">
            <!-- <a href="home.php"><button class="btn">LOGIN</button></a> -->
            <input type="submit" name="submit" value="LOGIN" class="btn">
        </div>
        </form>
        <div class="check">
            <p>Haven't account please register yourself</p>
        </div>
        <div class="form_group">
            <a href="register.php"><button class="btn">Register here</button></a>
        </div>
    </div>
</center>
</body>
</html>
<?php
    if(isset($_POST['submit']))
    //if login button submitted then its run
    {
        //login me jo user email aur password fill krega thats store in these variablee
        $email=$_POST['email'];
        $password=$_POST['password'];
        //connect the database
        require_once "conn.php";
        //check email and password are correctly filled or not
        $sql="SELECT * FROM login WHERE email='$email'";
        $result=mysqli_query($conn,$sql);
        $data=mysqli_fetch_array($result,MYSQLI_ASSOC);
        if($data)
        {
            if(password_verify($password,$data["password"]))
            {
                //creating session
                session_start();
                $_SESSION["user"]="yes";
                //for user dashboard page
                $_SESSION['Email_Address'] = $data['email'];
                header("Location: home.php");
                die();
            }
            else
            {
                echo "please enter valid password";
            }
        }
        else
        {
            echo "email doesn't exist";
        }
    }
?>