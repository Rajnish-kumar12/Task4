<!DOCTYPE html>
<html>
<head>
<title>Assign Chapters to Subjects</title>
</head>
<body>
<h1>Assign Chapters to Subjects</h1>
<form action="assignchaptertosubject.php" method="post">
<select name="subject">
<option value="">Select a subject</option>
<?php 
// $connection = mysqli_connect('localhost', 'root', 'root', 'userdata');
require_once "conn.php";
$sql = "SELECT * FROM subject";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $subject_id= $row['subject_id'];
echo "<option value='$subject_id'>$subject_id</option>";
}
?>
</select>
<br>
<br>
<select name="chapter">
<option value="">Select a chapter</option>
<?php
$sql = "SELECT * FROM chapter";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $chapter_no = $row['chapter_no'];
echo "<option value='$chapter_no'>$chapter_no</option>";
}
?>
</select>
<br>
<br>
<input type="submit" name="assign_chapter"value="Assign Chapter">
</form>
</body>
</html>
<?php
if (isset($_POST['assign_chapter'])) {

    $chapter_name = $_POST['chapter'];
    $subject_name = $_POST['subject'];

    $assign_chap_query = "insert into assign (chapter_id, subject_id) values ('$chapter_name', '$subject_name')";
   
    $result = mysqli_query($conn, $assign_chap_query);
    // print_r($assign_chap_query);
    // die();
    if ($result) {
       echo "assign chapter to subject";
    } else {
    }
}
?>