</html>
<?php
    // $conn=mysqli_connect("localhost","root","root","project1");
    require_once "conn.php";
    if($conn)
    {
        // echo "connected";
    }
    else
    {
        echo "not connected";
    }
    $Id=$_GET['id'];
    $query="SELECT * FROM login WHERE id=$Id";
    $result=mysqli_query($conn,$query);
    if($result)
    {
        $x=mysqli_fetch_assoc($result);
        // echo "<pre>";
        // print_r($x);
        // echo "</pre>";
        // while($x=mysqli_fetch_row($result));
        // {
        //     echo $x[];
        // }
        echo $x['fullname']." "." data are";
        echo "<br>";
        echo "................................................";
        echo "<br>";
        echo "email-- ".$x['email'];
        echo "<br>";
        echo "country-- ".$x['country'];
        echo "<br>";
        echo "state-- ".$x['state'];
        echo "<br>";
        echo "address-- ".$x['address'];
        echo "<br>";
        // echo $x['D_O_B'];
        // echo "<br>";
        // echo $x['Blood_group'];
        // echo "<br>";
    }
    else
    {
        echo "error".mysqli_error($conn);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="stylevp.css">
</head>
<body>
    <div class="viewp">
        <div class="viewpp">
        <a href="home.php"><button class="btnsss">Home page</button></a>
        </div>
        <div class="viewpp">
        <a href="view.php"><button class="btnsss">Back</button></a>
        </div>
    </div>
</body>