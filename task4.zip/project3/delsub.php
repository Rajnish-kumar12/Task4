<?php
require_once "conn.php";
if ($conn) {
    echo "database connected";
} else {
    echo "database not connected";
}
$subject_id = $_GET['si'];
$query = "DELETE FROM subject WHERE subject_id='$subject_id'";
$result = mysqli_query($conn, $query);
if ($result) {
    echo "record deleted successfully";
} else {
    echo "record not deleted successfully";
}
