<?php
    error_reporting(0);
    include "conn.php";
    $chapter_no=$_GET['cn'];
    $chapter_name=$_GET['cnm'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit chapter</title>
</head>
<body>
    <table border="2px" class="table">
    <form action="" method="get">
        <tr class="row">
        <td>chapter_no</td>
        <td><input type="text" value="<?php echo $chapter_no ?>"  name="chapter_no"  class="input"> </td>
        </tr>
        <tr class="row">
        <td>chapter_name</td>
        <td><input type="text" value="<?php echo $chapter_name?>" name="chapter_name" class="input"></td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <input type="submit" name="submit" class="btnssss">
            </td>
        </tr>
    </form>
    </table>
    <a href="viewchapter.php"><button class="btnssss">BACK</button></a>
</body>
</html>
<?php
    error_reporting(0);
    if($_GET['submit'])
    {
        include "conn.php";
        $chapter_no=$_GET['chapter_no'];
        $chapter_name=$_GET['chapter_name'];
        $query="UPDATE chapter SET chapter_no='$chapter_no', chapter_name='$chapter_name' WHERE chapter_no='$chapter_no'";
        $result9=mysqli_query($conn,$query).mysqli_error($conn);
        if($result9)
        {
            echo "updated";
        }
        else
        {
            echo "not updated, error";
        }
    }
?>