<?php
//start the session which are alredy started into the login page
session_start();
require_once "conn.php";
$Email = $_SESSION['Email_Address'];
$query1 = "SELECT accesstype.type, login.fullname FROM login  INNER JOIN usertype ON login.id = usertype.usertypeid 
    INNER JOIN accesstype ON usertype.accesstypeid = accesstype.id 
    WHERE login.email = '$Email'";
$result = mysqli_query($conn, $query1);
$data = mysqli_fetch_assoc($result);
// print_r($result);
// die();
//check the session that is started or not
if (!isset($_SESSION['user'])) {
    //if session value are not set then don't open the dashboard page send user to the login page to first login into the website
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
    <!-- <link rel="stylesheet" href="stylehome.css"> -->
    <link rel="stylesheet" href="home.css">
</head>

<body>
    <center>
    <marquee behavior="" direction="">
        <h3 style="color: aquamarine;">Welcome <?php echo $data['type'] ?></h3>
    </marquee>
    <?php if ($data['type'] === "admin") { ?>
        <!-- <p><h1 style="color: aquamarine;">Welcome, Admin!</h1></p> -->
        <div class="control"></div>
        <div class="one">
        <a href="subject.php"><button class="two">SUBJECT SECTION</button></a></button>
        </div>
        <div class="one">
        <a href="chapter.php"><button class="two">CHAPTER SECTION</button></a>
        </div>
        <div class="one">
        <a href="assignchaptertosubject.php"><button class="two">ASSIGN CHAPTERS TO SUBJECTS</button></a>
        </div>
        <div class="one">
        <a href="assignsubjecttostandard.php"><button class="two">ASSIGN SUBJECTS TO STANDARDS</button></a>
        </div>
        <div class="one">
        <a href="assignstudenttostandard.php"><button class="two">ASSIGN STUDENTS TO STANDARDS</button></a>
        </div>
        </div>
    <?php } elseif ($data['type'] === "teacher") { ?>
        <!-- <p>Welcome, Teacher!</p> -->
        <!-- <button><a href="subject.php">SUBJECT SECTION</a></button> -->
        <div class="control"></div>
        <div class="one">
        <a href="subject.php"><button class="two">SUBJECT SECTION</button></a></button>
        </div>
        <div class="one">
        <a href="chapter.php"><button class="two">CHAPTER SECTION</button></a>
        </div>
        <div class="one">
        <a href="assignchaptertosubject.php"><button class="two">ASSIGN CHAPTERS TO SUBJECTS</button></a>
        </div>
        <div class="one">
        <a href="assignsubjecttostandard.php"><button class="two">ASSIGN SUBJECTS TO STANDARDS</button></a>
        </div>
        <div class="one">
        <a href="assignstudenttostandard.php"><button class="two">ASSIGN STUDENTS TO STANDARDS</button></a>
        </div>
        </div>
    <?php } elseif ($data['type'] === "student") { ?>
        <p>Welcome, Student!</p>
    <?php } elseif ($data['type'] === "librarian") { ?>
        <p>Welcome, librarian</p>
    <?php } else { ?>
        <p>Welcome! Please contact the administrator for further instructions.</p>
    <?php } ?>
    <div class="home">
        <a href="logout.php"><button class="submit">Logout</button></a>
    </div>
    </center>
</body>

</html>