<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration form</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <form action="register.php" method="post">
            <div class="tag">
                <h1>PLEASE REGISTER HERE</h1>
            </div>
            <select name="category"  class="btn">
                <?php
                     require_once "conn.php";
                     $sql="select * from accesstype";
                     $result=mysqli_query($conn,$sql);
                     while($data=mysqli_fetch_array($result))
                     {
                 ?>
                         <option value="<?php echo $data['id']?>"><?php echo $data['type']?></option>
                     <?php } ?>
            </select>
            <div class="form_group">
                <input type="text" class="form-control" name="fullname" placeholder="enter your full name">
            </div>
            <div class="form_group">
                <input type="email" class="form-control" name="email" placeholder="email">
            </div>
            <!-- <div class="form_group">
                <input type="number" class="form-control" name="mobno" placeholder="mob no">
            </div> -->
            <div class="form_group">
                <input type="text" class="form-control" name="country" placeholder="country">
            </div>
            <div class="form_group">
                <input type="text" class="form-control" name="state" placeholder="state">
            </div>
            <div class="form_group">
                <input type="text" class="form-control" name="address" placeholder="address">
            </div>
            <div class="form_group">
                <input type="password" class="form-control" name="password" placeholder="password">
            </div>
            <div class="form_group">
                <input type="password" class="form-control" name="confirmpassword" placeholder="confirm password">
            </div>
            <div class="form_group">
                <input type="submit" name="submit" value="Register here" class="btn">
            </div>
        </form>
        <div class="check">
            <p>Already have an account then go to login:</p>
        </div>
        <div>
            <a href="login.php"><button class="btn">Login page</button></a>
        </div>
    </div>
</body>

</html>
<?php
error_reporting(0);
// include("$conn");
if (isset($_POST['submit'])) {
    // $category=$data['id'];
    $category=$_POST['category'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    // echo $fullname;
    $error = array();
    if (empty($fullname) or empty($email) or empty($country) or empty($state) or empty($address) or empty($password) or empty($confirmpassword)) {
        array_push($error, "<br>*All fields are required");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($error, "<br>*invalid email");
    }
    if (strlen($password) < 8) {
        array_push($error, "<br>*Password must of minimum 8 character");
    }
    if ($password !== $confirmpassword) {
        array_push($error, "<br>*password doesn't match");
    }
    if (count($error) > 0) {
        foreach ($error as $value) {
            echo $value;
        }
    } else {
        require_once "conn.php";
        $sql = "INSERT INTO login (fullname,email,country,state,address,password) VALUES('$fullname','$email','$country','$state','$address','$passwordHash')";
        $query = mysqli_query($conn, $sql);
        if ($query) {
            $query1 = "SELECT id FROM login where email='$email'";
            $result = mysqli_query($conn, $query1);
            $userdata = mysqli_fetch_assoc($result);
            $e = $userdata['id'];
            // print_r($e);
            // print_r($id);echo "<br>";
            $userdata_type = "INSERT INTO usertype (usertypeid,accesstypeid) VALUES ('$e','$category')";
            print_r($userdata_type);
            $userdata_type_result = mysqli_query($conn, $userdata_type);
            if ($userdata_type_result) {
                echo "submitted";
            } else {
                echo "not submitted";
            }
        }
        // echo "successfully registered";
    }
 
}

?>